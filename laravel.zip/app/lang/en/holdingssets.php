<?php

return array(

	'groups'   				=> 'Groups',
	'title'   					=> 'Holdings Sets',
	'create_group' 		=> 'Create Group',
	'title_create_group' => 'Create a Group of Holdings Set',
	'move_to_group'		=> 'Move to',
	'ok' 							=> 'Confirm',
);
