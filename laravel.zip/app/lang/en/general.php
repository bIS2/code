	<?php

return array(

	'yes' 							=> 'Yes',
	'no'  							=> 'No',
	'edit'  						=> 'Edit',
	'delete'  					=> 'Delete',
	'search'  					=> 'Search',
	'save_group'  			=> 'Save Group',
	'save'  						=> 'Save',
	'ok'  							=> 'OK',
	'close'  						=> 'Close',
	'disable_with'			=> 'Saving...',
	'all'								=> 'All',
	'logout'								=> 'logout',
	'profile'								=> 'Profile',
	'config'								=> 'Configuration',
	'type_criteria' 		=> 'Type to search',
	'placeholder_search'=> 'Type to search',
  'must_login' => 'Must be logged in.'

);
