<?php

return array(

	'cabinets'   				=> 'Cabinets',
	'title'   					=> 'Holdings',
	'create_cabinet' 		=> 'Create Cabinet',
	'title_create_cabinet' => 'Create Cabinet of Holdings',
	'move_to_cabinet'		=> 'Move to',
	'ok2' 							=> 'Confirm',
	'comment' 					=> 'Comment'
);
