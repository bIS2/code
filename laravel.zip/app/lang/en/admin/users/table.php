<?php

return array(

	'first_name' => 'First Name',
	'last_name'  => 'Last Name',
	'user_id'  => 'User Id',
	'username'  => 'Username',
	'email'      => 'Email',
	'groups'     => 'Groups',
	'roles'     => 'Roles',
	'activated'  => 'Activated',
	'created_at' => 'Created at',
	'library' => 'Library',

);
