<?php

class GroupObserver {

    public function creating($model) {
    	
    }

    public function saved($model)
    {
        //
    }

}