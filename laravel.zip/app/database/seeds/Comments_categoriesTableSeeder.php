<?php

class Comments_categoriesTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('comments_categories')->truncate();

		$comments_categories = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('comments_categories')->insert($comments_categories);
	}

}
