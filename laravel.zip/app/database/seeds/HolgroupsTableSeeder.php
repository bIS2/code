<?php

class HolgroupsTableSeeder extends Seeder {

	public function run()
	{
		// Uncomment the below to wipe the table clean before populating
		// DB::table('holgroups')->truncate();

		$holgroups = array(

		);

		// Uncomment the below to run the seeder
		// DB::table('holgroups')->insert($holgroups);
	}

}
