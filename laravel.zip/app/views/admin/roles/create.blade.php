@extends('admin.layouts.modal')

{{-- Content --}}
@section('content')

	{{-- Create Role Form --}}

	@include('admin.roles._form')

@stop
