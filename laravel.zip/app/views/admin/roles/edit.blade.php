@extends('admin.layouts.modal')

{{-- Content --}}
@section('content')


	{{-- Edit Role Form --}}

	@include('admin.roles._form')
	
@stop
