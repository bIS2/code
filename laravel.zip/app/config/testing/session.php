<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| Default Session Driver
	|--------------------------------------------------------------------------
	|
	| This option controls the default session "driver" that will be used on
<<<<<<< HEAD
	| requets. By default, we will use the light-weight cookie driver but
	| you may specify any of the other wonderful drivers provided here.
	|
	| Supported: "cookie", file", "database", "apc",
=======
	| requests. By default, we will use the lightweight native driver but
	| you may specify any of the other wonderful drivers provided here.
	|
	| Supported: "native", "cookie", "database", "apc",
>>>>>>> e72b12092986c2ff70a616eebd3d2a9675ee5b92
	|            "memcached", "redis", "array"
	|
	*/

	'driver' => 'array',

);